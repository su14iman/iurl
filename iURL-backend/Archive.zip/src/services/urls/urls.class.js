const { Service } = require('feathers-mongoose');

exports.Urls = class Urls extends Service {
  
};
